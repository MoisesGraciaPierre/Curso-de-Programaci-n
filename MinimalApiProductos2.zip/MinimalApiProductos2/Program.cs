﻿using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Swagger + definición de API Key
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("ApiKey", new OpenApiSecurityScheme
    {
        Description = "Encabezado personalizado: X-API-KEY = 12345",
        In = ParameterLocation.Header,
        Name = "X-API-KEY",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "ApiKeyScheme"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "ApiKey"
                }
            },
            new List<string>()
        }
    });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.Use(async (context, next) =>
{
    if (!context.Request.Headers.TryGetValue("X-API-KEY", out var key) || key != "12345")
    {
        context.Response.StatusCode = 401;
        await context.Response.WriteAsync("No autorizado. Falta X-API-KEY.");
        return;
    }

    await next();
});

// Lista en memoria
var productos = new List<Producto>
{
    new Producto { Id = 1, Nombre = "Laptop", Precio = 1200 },
    new Producto { Id = 2, Nombre = "Mouse", Precio = 20 }
};

// GET
app.MapGet("/productos", () =>
{
    return Results.Ok(productos);
})
.WithName("ObtenerProductos")
.WithTags("Productos");

// POST
app.MapPost("/productos", (Producto nuevoProducto) =>
{
    nuevoProducto.Id = productos.Count + 1;
    productos.Add(nuevoProducto);
    return Results.Created($"/productos/{nuevoProducto.Id}", nuevoProducto);
})
.WithName("AgregarProducto")
.WithTags("Productos");

app.Run();

// ✅ Clase debe ir al final
public class Producto
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public decimal Precio { get; set; }
}

