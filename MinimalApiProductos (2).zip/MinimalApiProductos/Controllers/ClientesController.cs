﻿using Microsoft.AspNetCore.Mvc;
using ClientesApiController.Models;

namespace ClientesApiController.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClientesController : ControllerBase
    {
        // Lista en memoria simulando una base de datos
        private static List<Cliente> clientes = new List<Cliente>
        {
            new Cliente { Id = 1, Nombre = "Juan Pérez", Email = "juan@example.com" },
            new Cliente { Id = 2, Nombre = "Ana Gómez", Email = "ana@example.com" }
        };

        // GET /api/clientes
        [HttpGet]
        public ActionResult<IEnumerable<Cliente>> GetClientes()
        {
            return Ok(clientes);
        }

        // GET /api/clientes/1
        [HttpGet("{id}")]
        public ActionResult<Cliente> GetCliente(int id)
        {
            var cliente = clientes.FirstOrDefault(c => c.Id == id);
            if (cliente == null) return NotFound();
            return Ok(cliente);
        }

        // POST /api/clientes
        [HttpPost]
        public ActionResult<Cliente> CrearCliente([FromBody] Cliente nuevo)
        {
            nuevo.Id = clientes.Count + 1;
            clientes.Add(nuevo);
            return CreatedAtAction(nameof(GetCliente), new { id = nuevo.Id }, nuevo);
        }

        // PUT /api/clientes/1
        [HttpPut("{id}")]
        public IActionResult ActualizarCliente(int id, [FromBody] Cliente actualizado)
        {
            var cliente = clientes.FirstOrDefault(c => c.Id == id);
            if (cliente == null) return NotFound();

            cliente.Nombre = actualizado.Nombre;
            cliente.Email = actualizado.Email;
            return NoContent();
        }

        // DELETE /api/clientes/1
        [HttpDelete("{id}")]
        public IActionResult EliminarCliente(int id)
        {
            var cliente = clientes.FirstOrDefault(c => c.Id == id);
            if (cliente == null) return NotFound();

            clientes.Remove(cliente);
            return NoContent();
        }
    }
}
